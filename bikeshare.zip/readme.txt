Some of the functionality included on this project was taken from the template available for this.

I have looked for some method specification at Pandas website, and take some ideas from Python threads from Stackoverflow website

This code runs with ipython 7.12.0 and Pandas 1.0.1, under Windows 10 
